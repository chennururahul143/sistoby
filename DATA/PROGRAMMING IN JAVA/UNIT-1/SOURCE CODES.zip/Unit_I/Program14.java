public class Program14 {
    public static void main(String args[]) {
        boolean t = true;

        System.out.println("This statement is printed on the console");

        if (t) return;

        System.out.println("This statement never gets executed");
    }
}