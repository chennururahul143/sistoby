public class Program5 {
    public static void main(String [] args) {
        byte myByte = 60;           // Byte
        short myShort = 6000;       // Short
        int myInteger = 600000;     // Integer (whole number)
        long myLong = 60000000;     // Long
        double myDouble = 6.67;     // Double (default for decimal values)
        float myFloat = 6.66f;      // Floating point number        
        char myChar1 = 'A';          // Character
        char myChar2 = 97;          // Character
        boolean myBoolean = true;   // Boolean        
        System.out.println("Byte:"+myByte);
        System.out.println("Short:"+myShort);
        System.out.println("Integer:"+myInteger);
        System.out.println("Long:"+myLong);
        System.out.println("Float:"+myFloat);
        System.out.println("Double:"+myDouble);
        System.out.println("Char1:"+myChar1);
        System.out.println("Char2:"+myChar2);
        System.out.println("Boolean:"+myBoolean);
    }
}