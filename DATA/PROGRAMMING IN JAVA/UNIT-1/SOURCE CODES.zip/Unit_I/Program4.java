class Program4 {
    public static void main(String [] args) {
        //int i;
        for(int i = 10; i>0; i = i-1) {
            System.out.println("Current Value of i is : " + i);
        }
    }
}