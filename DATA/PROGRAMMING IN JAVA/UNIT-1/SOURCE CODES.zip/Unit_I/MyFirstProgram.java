/* This is my 
First Java Program */
/* - Multi Line Comment Statement */
class MyFirstProgram {
    //  Trigger the main Method. 
    // Single Line Comment
    public static void main(String [] args) {
        System.out.println("SIST");
    }
}
