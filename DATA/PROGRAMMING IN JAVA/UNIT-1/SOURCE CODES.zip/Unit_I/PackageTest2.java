// Demo package p2.
package p2;
// Instantiate the various classes in p2.
public class PackageTest2 {
	public static void main(String args[]) {
		ProtectedClass ob1 = new ProtectedClass();
		OtherPackage ob2 = new OtherPackage();
	}
}