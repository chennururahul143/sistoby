class Program2 {
	public static void main(String [] args) {
		int year;
		year = 2020;
		System.out.println("Current Year is : " + year);
		int nextYear = year + 1;
		System.out.println("Next Year is : " + nextYear);
	}
} 