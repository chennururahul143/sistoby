// Demo package p2.
package p2;

// Instantiate the various classes in p2.
public class PackageTest2_P7 {
	public static void main(String args[]) {
		ProtectedClass2_P4 ob1 = new ProtectedClass2_P4();
		OtherPackage_P5 ob2 = new OtherPackage_P5();
	}
}