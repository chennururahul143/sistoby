// For using Builtin Packages of JAVA
package sist.be.cse.year2020.b1;
import java.util.Date;

public class Program2 {
	public static void main(String [] args) {
		Date d1 = new Date();
		System.out.println(d1);
	}
}
