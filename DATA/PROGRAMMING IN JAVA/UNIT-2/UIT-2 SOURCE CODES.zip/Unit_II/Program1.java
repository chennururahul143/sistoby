package sist;

public class Program1 {
	public static void main(String [] args) {
		System.out.println("Introduction to Package");
	}
}