package unit2;

public interface CalculatorInterface {
	public int add(int a, int b);
	public int sub(int a, int b);
	public int mult(int a, int b);
	public int div(int a, int b);
}