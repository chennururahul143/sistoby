// Access Specifier
// Derived Class - Program 6

// Demo package p1.
package p1;
// Instantiate the various classes in p1.
public class PackageTest1_P6 {
	public static void main(String args[]) {
		// Super Class
		//ProtectedClass_P1 ob1 = new ProtectedClass_P1(); 
		// Inheritance is applied
		//DerivedClass_P2 ob2 = new DerivedClass_P2();
		// Creation of an Object 
		SamePackage_P3 ob3 = new SamePackage_P3();
	}
}